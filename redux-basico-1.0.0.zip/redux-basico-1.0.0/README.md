# Redux Básico

Este es el ejercicio hecho en el curso de REDUX mío de Udemy.

## Instalación
Descarguen o clonen el repositorio, luego ejecuten __npm install__ para reconstruir los módulos de node.

```
npm install
```

### Ejecutar archivos

Si tienen instalado de forma global el ts-node

```
ts-node app-1.ts
ts-node app-2.ts
ts-node app-3.ts
ts-node app-4.ts
```

Si no, entonces

```
./node_modules/.bin/ts-node app-1.ts
./node_modules/.bin/ts-node app-2.ts
./node_modules/.bin/ts-node app-3.ts
./node_modules/.bin/ts-node app-4.ts
```