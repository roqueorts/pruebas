

export interface AppState {
    contador: number;
}