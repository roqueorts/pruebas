import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ingreso-egreso',
  templateUrl: './ingreso-egreso.component.html',
  styles: []
})
export class IngresoEgresoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
